<form action="/" class="form-inline">

  <div class="input-group">
    
    <input id="search" type="text" class="form-control" name="s" placeholder="Search text here">
    <span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span>
  </div>
  <div class="form-group">
    <input type="submit" class="btn btn-default" value="Submit"/>
  </div>

</form>