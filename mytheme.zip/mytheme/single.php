<?php get_header('secondary');?>

            <?php get_template_part( 'includes/section', 'blogcontent' ); ?>

<?php get_footer();?>