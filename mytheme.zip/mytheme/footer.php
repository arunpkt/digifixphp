<?php wp_head();?>
 <!-- start footer -->
 <footer class="footer">
        <div class="container">
            <div class="row align-items-center">
                <!-- start logo -->
                <div class="col-md-3 text-center text-lg-left">
                    <a href="index.html">
                        <!-- <img class="footer-logo" src="./images/logo.png" data-rjs="images/logo@2x.png" alt="Digi fix media"> -->
                        <h6 class="footer logo">DIGIFIX MEDIA</h6>
                    </a>
                </div>
                <!-- end logo -->
                <!-- start copyright -->
                <div class="col-md-6 text-center">
                    ©2020 Digi Fix Media is proudly powered by <a href="http://www.arunkumar.website" target="_blank" title="">arunkumar.website</a>
                </div>
                <!-- end copyright -->
                <!-- start social media -->
                <div class="col-md-3 text-center text-lg-right">
                        <div class="social-icon float-lg-right">
                            <ul class="small-icon mb-0">
                                <li><a class="facebook text-black" href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>
                                <li><a class="twitter text-black" href="https://twitter.com/" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                <li><a class="google text-black" href="https://plus.google.com/" target="_blank"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a class="dribbble text-black" href="https://dribbble.com/" target="_blank"><i class="fab fa-dribbble mr-0" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- end social media -->
             
            </div>
        </div>
    </footer>
    <!-- end footer -->
    <!-- javascript libraries -->
    <script type="text/javascript" src="./js/jquery.js"></script>
    <script type="text/javascript" src="./js/modernizr.js"></script>
    <script type="text/javascript" src="./js/modernizr.js"></script>
    <script type="text/javascript" src="./js/bootstrap.bundle.js"></script>
    <script type="text/javascript" src="./js/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="./js/smooth-scroll.js"></script>
    <script type="text/javascript" src="./js/jquery.appear.js"></script>
        <!-- et line icon --> 
        <link rel="stylesheet" href="./css/et-line-icons.css">
    <!-- menu navigation -->
    <script type="text/javascript" src="./js/jquery.nav.js"></script>
    <!-- animation -->
    <script type="text/javascript" src="./js/wow.min.js"></script>
    <!-- page scroll -->
    <script type="text/javascript" src="./js/page-scroll.js"></script>
    <!-- swiper carousel -->
    <script type="text/javascript" src="./js/swiper.min.js"></script>
    <!-- counter -->
    <script type="text/javascript" src="./js/jquery.count-to.js"></script>
    <!-- parallax -->
    <script type="text/javascript" src="./js/jquery.stellar.js"></script>
    <!-- magnific popup -->
    <script type="text/javascript" src="./js/jquery.magnific-popup.min.js"></script>
    <!-- portfolio with shorting tab -->
    <script type="text/javascript" src="./js/isotope.pkgd.min.js"></script>
    <!-- images loaded -->
    <script type="text/javascript" src="./js/imagesloaded.pkgd.min.js"></script>
    <!-- pull menu -->
    <script type="text/javascript" src="./js/classie.js"></script>
    <script type="text/javascript" src="./js/hamburger-menu.js"></script>
    <!-- counter  -->
    <script type="text/javascript" src="./js/counter.js"></script>
    <!-- fit video  -->
    <script type="text/javascript" src="./js/jquery.fitvids.js"></script>
    <!-- skill bars  -->
    <script type="text/javascript" src="./js/skill.bars.jquery.js"></script>
    <!-- justified gallery  -->
    <script type="text/javascript" src="./js/justified-gallery.min.js"></script>
    <!--pie chart-->
    <script type="text/javascript" src="./js/jquery.easypiechart.min.js"></script>
    <!-- instagram -->
    <script type="text/javascript" src="./js/instafeed.min.js"></script>
    <!-- retina -->
    <script type="text/javascript" src="./js/retina.min.js"></script>
    <!-- revolution -->
    <script type="text/javascript" src="./js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="./js/jquery.themepunch.revolution.min.js"></script>
    <!-- <script type="text/javascript" src="./js/main.js"></script> -->
    <script type="text/javascript" src="./js/common.js"></script>
 
</body>
</html>